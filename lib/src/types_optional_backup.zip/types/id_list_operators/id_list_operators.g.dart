// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'id_list_operators.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$IdListOperatorsImpl _$$IdListOperatorsImplFromJson(
        Map<String, dynamic> json) =>
    _$IdListOperatorsImpl(
      inList: json['inList'] as String,
    );

Map<String, dynamic> _$$IdListOperatorsImplToJson(
        _$IdListOperatorsImpl instance) =>
    <String, dynamic>{
      'inList': instance.inList,
    };
