// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'native_auth_input.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NativeAuthInputImpl _$$NativeAuthInputImplFromJson(
        Map<String, dynamic> json) =>
    _$NativeAuthInputImpl(
      password: json['password'] as String,
      username: json['username'] as String,
    );

Map<String, dynamic> _$$NativeAuthInputImplToJson(
        _$NativeAuthInputImpl instance) =>
    <String, dynamic>{
      'password': instance.password,
      'username': instance.username,
    };
