// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'number_range.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NumberRangeImpl _$$NumberRangeImplFromJson(Map<String, dynamic> json) =>
    _$NumberRangeImpl(
      end: (json['end'] as num).toDouble(),
      start: (json['start'] as num).toDouble(),
    );

Map<String, dynamic> _$$NumberRangeImplToJson(_$NumberRangeImpl instance) =>
    <String, dynamic>{
      'end': instance.end,
      'start': instance.start,
    };
