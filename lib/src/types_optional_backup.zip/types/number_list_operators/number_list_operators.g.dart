// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'number_list_operators.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NumberListOperatorsImpl _$$NumberListOperatorsImplFromJson(
        Map<String, dynamic> json) =>
    _$NumberListOperatorsImpl(
      inList: (json['inList'] as num).toDouble(),
    );

Map<String, dynamic> _$$NumberListOperatorsImplToJson(
        _$NumberListOperatorsImpl instance) =>
    <String, dynamic>{
      'inList': instance.inList,
    };
