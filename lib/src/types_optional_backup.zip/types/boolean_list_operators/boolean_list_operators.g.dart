// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'boolean_list_operators.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BooleanListOperatorsImpl _$$BooleanListOperatorsImplFromJson(
        Map<String, dynamic> json) =>
    _$BooleanListOperatorsImpl(
      inList: json['inList'] as bool,
    );

Map<String, dynamic> _$$BooleanListOperatorsImplToJson(
        _$BooleanListOperatorsImpl instance) =>
    <String, dynamic>{
      'inList': instance.inList,
    };
